/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>

#include "particle_filter.h"

void ParticleFilter::init(double x, double y, double theta, double std[]) {
    std::default_random_engine gen;
    std::normal_distribution<double> x_distribution(x, std[0]);
    std::normal_distribution<double> y_distribution(y, std[1]);
    std::normal_distribution<double> theta_distribution(theta, std[2]);
    
    num_particles = 750;
    for (unsigned int i = 0; i < num_particles; i++) {
        Particle particle;
        particle.x = x_distribution(gen);
        particle.y = y_distribution(gen);
        particle.theta = theta_distribution(gen);
        particle.weight = 1;
        particles.push_back(particle);
    }
    
    weights.resize(num_particles);
    
    is_initialized = true;


}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
    std::default_random_engine gen;
    
    std::normal_distribution<double> x_noise(0, std_pos[0]);
    std::normal_distribution<double> y_noise(0, std_pos[1]);
    std::normal_distribution<double> theta_noise(0, std_pos[2]);
    
    for (unsigned int i = 0; i < num_particles; i++) {
        Particle particle = particles[i];
        float theta = particle.theta + yaw_rate * delta_t;
        float vel_yaw   = velocity / yaw_rate;
        particle.x += vel_yaw * (sin(theta) - sin(particle.theta)) + x_noise(gen);
        particle.y += vel_yaw * (cos(particle.theta) - cos(theta)) + y_noise(gen);
        particle.theta = theta + theta_noise(gen);
        
        particles[i] = particle;
    }

}

void ParticleFilter::dataAssociation(std::vector<LandmarkObs> predicted, std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the 
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to 
	//   implement this method and use it as a helper during the updateWeights phase.

}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
		std::vector<LandmarkObs> observations, Map map_landmarks) {
    for (int p = 0; p < num_particles; p++)
    {
        LandmarkObs obs;
        double transX, transY;
        particles[p].weight = 1.0;
        
        for(int i = 0; i < observations.size(); i++)
        {
            obs = observations[i];
            double best_dist = sensor_range;
            int index = -1;
            transX = particles[p].x+(obs.x*cos(particles[p].theta)-obs.y*sin(particles[p].theta));
            transY = particles[p].y+(obs.x*sin(particles[p].theta)+obs.y*cos(particles[p].theta));
            for (int j = 0; j < map_landmarks.landmark_list.size(); j++)
            {
                double dist = sqrt(pow(transX-map_landmarks.landmark_list[j].x_f,2.0)+pow(transY-map_landmarks.landmark_list[j].y_f,2.0));
                if(dist < best_dist)
                {
                    best_dist = dist;
                    index = j;
                }
            }
            
            if(index > -1)
            {
                double prod = 1/(2*M_PI*std_landmark[0]*std_landmark[1])*exp(-(pow(transX-map_landmarks.landmark_list[index].x_f,2.0)/(2*pow(std_landmark[0],2.0))+pow(transY-map_landmarks.landmark_list[index].y_f,2.0)/(2*pow(std_landmark[1],2.0))));
                if(prod > 0)
                {
                    particles[p].weight*= prod;
                }
                
            }
        }
        weights[p] = particles[p].weight;
        
    }

}

void ParticleFilter::resample() {
    std::default_random_engine gen;
    std::discrete_distribution<int> distribution(weights.begin(), weights.end());
    
    std::vector<Particle> resample;
    
    for (int i = 0; i < num_particles; i++)
    {
        
        resample.push_back(particles[distribution(gen)]);
    }
    
    particles = resample;

}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
